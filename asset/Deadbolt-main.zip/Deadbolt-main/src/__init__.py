"""
Deadbolt Ransomware Protection System
Core package for ransomware detection and prevention
"""

__version__ = "5.0.0"
__author__ = "Ankit Mondal"
__description__ = "Behavior-based ransomware detection and prevention system"